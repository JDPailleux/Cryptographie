
DM de Cryptographie de PAILLEUX Jean-Didier et FERON Robin.

Comment tester le code ?
	
	-- Compilation => taper dans le terminal: make all
	-- Execution   => taper dans le terminal: make run 
	
Déroulement du programme :

	-- Tout d'abord le programme va demander le nombre "n" sur lequel sera exécuté les deux tests de primalité.
	-- Ensuite il va demander le nombre de répétitions "k" souhaité.
	-- Le programme affichera le résultat pour les deux tests de primalité ( Fermat et Miller-Rabin).
	-- Enfin le programme demandera si oui on non vous souhaitez tester un autre nombre. (0 : Non, et 1: Oui)
